document.getElementById("date").innerHTML = new Date().toDateString();

function myFunction() {
    var Change = document.getElementById("change");
    Change.style.color = "red"; 

  }